def hello(event, context):
    print("Welcpme to Terraform")
